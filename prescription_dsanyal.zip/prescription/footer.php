<!--BEGIN footer-->
            <div class="footer">
                
                <!--BEGIN footer left-->
                <div class="f_left">
                &copy; 2012 <b>Prescription</b>
                </div>
                <!--END of footer left-->
                
                <!--BEGIN footer right-->
                <div class="f_right">
                Developed by : <b>P.G.Infoservices</b>
                </div>
                <!--END of footer right-->
				</div>
<!--END of footer-->