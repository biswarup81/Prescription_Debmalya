
<div class="col-sm-3 col-md-2 sidebar">
          <ul class="nav nav-sidebar">
            <li class="active"><a href="#">Overview <span class="sr-only">(current)</span></a></li>
            <li><a href="reports.php">Reports</a></li>
            <li><a href="master.php">Master data</a></li>
            <li><a href="visit_list.php">Visit List</a></li>
          </ul>
         
          
</div>