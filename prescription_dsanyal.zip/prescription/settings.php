<?php include_once "./inc/datacon.php";
include_once "./inc/header.php"; ?>

    <?php include './inc/dashboard_topnav.php'; ?>

    <div class="container-fluid">
      <div class="row">
        <?php include './inc/dashboard_sidenav.php'; ?>
        <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
          <h1 class="page-header">Settings</h1>

         

          
          <div class="row">
        		<div class="col-md-12">
        		<h2 class="sub-header">Day Wise Visit report</h2>
        		
        		</div>
        		
          
          
            
          
        </div>
      </div>
    </div>
	</div>
   <?php include_once './inc/footer.php';?>
  </body>
</html>
        